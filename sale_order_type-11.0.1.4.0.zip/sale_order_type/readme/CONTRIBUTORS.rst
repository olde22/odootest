* `Vermon <http://www.grupovermon.com>`_

  * Carlos Sánchez Cifuentes <csanchez@grupovermon.com>

* `AvanzOsc <http://avanzosc.es>`_

  * Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
  * Ana Juaristi <anajuaristi@avanzosc.es>
  * Daniel Campos <danielcampos@avanzosc.es>
  * Ainara Galdona <ainaragaldona@avanzosc.es>

* `Agile Business Group <https://www.agilebg.com>`_

  * Lorenzo Battistini <lorenzo.battistini@agilebg.com>
  * Simone Rubino <simone.rubino@agilebg.com>

* `Niboo <https://www.niboo.be/>`_

  * Samuel Lefever <sam@niboo.be>
  * Pierre Faniel <pierre@niboo.be>

* `Tecnativa <https://www.tecnativa.com>`_

  * Pedro M. Baeza
  * David Vidal
  * Carlos Dauden

Do not contact contributors directly about support or help with technical issues.
