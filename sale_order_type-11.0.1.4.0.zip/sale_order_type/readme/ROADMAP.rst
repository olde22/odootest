* Manage the order of *sale.order.type.rule* similar to *product.pricelist.item* (see field *applied_on*) instead of using *sequence*.
